#pragma once
int repeting_value = 34;